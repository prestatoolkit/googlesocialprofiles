<?php
/**
 * Google Social Profiles
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category  front_office_features
 * @package   googlesocialprofiles
 * @author    PrestaToolkit
 * @copyright Copyright 2021 © PrestaToolkit All right reserved
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

if (!defined('_PS_VERSION_'))
exit;

class GoogleSocialProfiles extends Module
{
	public function __construct()
	{
	$this->name = 'googlesocialprofiles';
	$this->tab = 'seo';
	$this->version = '1.0.1';
	$this->author = 'PrestaToolkit';
	$this->bootstrap = true;
	parent::__construct();
	$this->displayName = $this->l('Google Social Profiles');
	$this->description = $this->l('Show your orginzation and social profiles on Google search.');
	}

	public function install()
	{
		return (parent::install() && $this->registerHook('displayTop'));
	}

	public function uninstall()
	{
		return (parent::uninstall());
	}
	
	public function getContent()
	{
		 $html = '<div class="panel" style="text-align:center"><a target="_blank" href="http://addons.prestashop.com/en/2_community-developer?contributor=360202"><img src="'.$this->_path.'views/img/banner.jpg"></a></div>';
		return $this->postProcess().$html.$this->renderForm();
	}

	public function postProcess()
	{
		if (Tools::isSubmit('submitConfig'))
		{
			Configuration::updateValue('GOOGLE_SOCIAL_LOGO', Tools::getValue('GOOGLE_SOCIAL_LOGO'));
			Configuration::updateValue('GOOGLE_SOCIAL_PHONE', Tools::getValue('GOOGLE_SOCIAL_PHONE'));
			Configuration::updateValue('GOOGLE_SOCIAL_FB', Tools::getValue('GOOGLE_SOCIAL_FB'));
			Configuration::updateValue('GOOGLE_SOCIAL_TW', Tools::getValue('GOOGLE_SOCIAL_TW'));
			Configuration::updateValue('GOOGLE_SOCIAL_INS', Tools::getValue('GOOGLE_SOCIAL_INS'));
			Configuration::updateValue('GOOGLE_SOCIAL_GPLUS', Tools::getValue('GOOGLE_SOCIAL_GPLUS'));
			Configuration::updateValue('GOOGLE_SOCIAL_LIN', Tools::getValue('GOOGLE_SOCIAL_LIN'));
			Configuration::updateValue('GOOGLE_SOCIAL_YT', Tools::getValue('GOOGLE_SOCIAL_YT'));
			$this->_clearCache('top.tpl');
			return $this->displayConfirmation($this->l('The settings have been updated.'));
		}
		return '';
	}
	
	public function renderForm()
	{
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Settings'),
					'icon' => 'icon-config'
				),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('Logo URL'),
						'name' => 'GOOGLE_SOCIAL_LOGO',
						'desc' => $this->l('Logo will be used to show on SRP.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Phone Number'),
						'name' => 'GOOGLE_SOCIAL_PHONE',
						'desc' => $this->l('e.g +1 554 435 332, will be used to show on SRP.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Facebook page'),
						'name' => 'GOOGLE_SOCIAL_FB',
						'desc' => $this->l('for example prestashop, Please do NOT put complete URL.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Twitter page'),
						'name' => 'GOOGLE_SOCIAL_TW',
						'desc' => $this->l('for example prestashop, Please do NOT put complete URL.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Instagram page'),
						'name' => 'GOOGLE_SOCIAL_INS',
						'desc' => $this->l('for example prestashop, Please do NOT put complete URL.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Google Plus page'),
						'name' => 'GOOGLE_SOCIAL_GPLUS',
						'desc' => $this->l('for example +prestashop, Please do NOT put complete URL.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Linkedin page'),
						'name' => 'GOOGLE_SOCIAL_LIN',
						'desc' => $this->l('for example prestashop, Please do NOT put complete URL.')
					),
					array(
						'type' => 'text',
						'label' => $this->l('Youtube page'),
						'name' => 'GOOGLE_SOCIAL_YT',
						'desc' => $this->l('for example prestashop, Please do NOT put complete URL.')
					),
				),
				'submit' => array(
					'title' => $this->l('Save')
				)
			),
		);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->module = $this;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitConfig';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'uri' => $this->getPathUri(),
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);
		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues()
	{
		$fields = array();
		$fields['GOOGLE_SOCIAL_LOGO'] = Configuration::get('GOOGLE_SOCIAL_LOGO');
		$fields['GOOGLE_SOCIAL_PHONE'] = Configuration::get('GOOGLE_SOCIAL_PHONE');
		$fields['GOOGLE_SOCIAL_FB'] = Configuration::get('GOOGLE_SOCIAL_FB');
		$fields['GOOGLE_SOCIAL_TW'] = Configuration::get('GOOGLE_SOCIAL_TW');
		$fields['GOOGLE_SOCIAL_INS'] = Configuration::get('GOOGLE_SOCIAL_INS');
		$fields['GOOGLE_SOCIAL_GPLUS'] = Configuration::get('GOOGLE_SOCIAL_GPLUS');
		$fields['GOOGLE_SOCIAL_LIN'] = Configuration::get('GOOGLE_SOCIAL_LIN');
		$fields['GOOGLE_SOCIAL_YT'] = Configuration::get('GOOGLE_SOCIAL_YT');
		return $fields;
	}
	
	public function hookDisplayTop()
	{
		$sp_fb = Configuration::get('GOOGLE_SOCIAL_FB');
		$sp_fb = empty($sp_fb) ? '' : 'http://www.facebook.com/'.$sp_fb;
		$sp_tw = Configuration::get('GOOGLE_SOCIAL_TW');
		$sp_tw = empty($sp_tw) ? '' : 'http://www.twitter.com/'.$sp_tw;
		$sp_in = Configuration::get('GOOGLE_SOCIAL_INS');
		$sp_in = empty($sp_in) ? '' : 'http://instagram.com/'.$sp_in;
		$sp_gp = Configuration::get('GOOGLE_SOCIAL_GPLUS');
		$sp_gp = empty($sp_gp) ? '' : 'http://plus.google.com/'.$sp_gp;
		$sp_lin = Configuration::get('GOOGLE_SOCIAL_LIN');
		$sp_lin = empty($sp_lin) ? '' : 'http://www.linkedin.com/in/'.$sp_lin;
		$sp_yt = Configuration::get('GOOGLE_SOCIAL_YT');
		$sp_yt = empty($sp_yt) ? '' : 'http://www.youtube.com/user/'.$sp_yt;
		$google_sp_array = array('google_sp_fb' => $sp_fb,
				'google_sp_tw' => $sp_tw,
				'google_sp_ins' => $sp_in,
				'google_sp_gplus' => $sp_gp,
				'google_sp_link' => $sp_lin,
				'google_sp_yt' => $sp_yt,
				);
		$google_sp_array = array_filter($google_sp_array);
		$force_ssl = (Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'));
		$this->smarty->assign(array(
				'web_url' => ($force_ssl > 0) ? _PS_BASE_URL_SSL_.__PS_BASE_URI__ : _PS_BASE_URL_.__PS_BASE_URI__,
				'sp_logo' => Configuration::get('GOOGLE_SOCIAL_LOGO'),
				'sp_phone' => Configuration::get('GOOGLE_SOCIAL_PHONE'),
				'google_sp_array' => $google_sp_array,
		));
		if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
			return $this->display(__FILE__, 'top17.tpl');
		}
		else {
			return $this->display(__FILE__, 'top.tpl');
		}
	}
}